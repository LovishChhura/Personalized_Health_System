from django.apps import AppConfig


class HomeRemediesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'home_remedies'
