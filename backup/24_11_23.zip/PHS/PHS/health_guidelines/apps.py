from django.apps import AppConfig


class HealthGuidelinesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'health_guidelines'
